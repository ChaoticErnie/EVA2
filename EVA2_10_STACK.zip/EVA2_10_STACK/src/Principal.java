
import java.util.logging.Level;
import java.util.logging.Logger;

public class Principal {

    public static void main(String[] args) {

        Stack stack = new Stack();

        stack.push(new Nodo(10));
        stack.push(new Nodo(11));
        stack.push(new Nodo(12));
        stack.push(new Nodo(13));
        stack.push(new Nodo(14));

        stack.print();

        System.out.println("Cima de la pila: " + stack.peak());
        try {
            System.out.println("Cima de la pila: " + stack.pop());
        } catch (Exception e) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
