
public class Nodo {

    private int x;
    private Nodo next;

    public Nodo() {
        // El valor de nuestra referencia comience en null
        next = null;

    }

    public Nodo(int dato) {
        x = dato;
        next = null;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public Nodo getNext() {
        return next;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }
}
