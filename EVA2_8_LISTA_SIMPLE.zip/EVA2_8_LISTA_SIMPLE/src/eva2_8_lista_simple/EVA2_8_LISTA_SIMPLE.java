package eva2_8_lista_simple;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA2_8_LISTA_SIMPLE {
    
    public static void main(String[] args) {
        
        Lista myList = new Lista();
        myList.add(new Nodo(4));
        
        
        
        boolean empty = myList.isEmpty();
        if (empty) {
            System.out.println("lista vacia");
        } else {
            System.out.println("lista con nodos");
        }
        
    }
    
}
