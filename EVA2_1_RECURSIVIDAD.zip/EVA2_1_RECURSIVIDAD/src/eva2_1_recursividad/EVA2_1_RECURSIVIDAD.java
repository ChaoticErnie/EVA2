package eva2_1_recursividad;

import java.util.Scanner;

public class EVA2_1_RECURSIVIDAD {

    public static void main(String[] args) {

        Scanner userInput = new Scanner(System.in);

        System.out.println("Introduce un número");
        int x = userInput.nextInt();
        for (int i = x; i >= 1; i--) {
            System.out.print(i + " - ");
        }

        System.out.println("\n");

        fakeFor(x);

        System.out.println("\n");

        alrevez(x);
    }

    public static void fakeFor(int x) {
        System.out.print(x + " - ");
        if (x > 1) {
            fakeFor(x - 1);
        }
    }

    public static void alrevez(int x) {
        System.out.println(x + " - ");
        if (10 > (x )) {
            alrevez(x + 1);
        }
    }

}

// Imprimir los números del 1 al número que el usuario introduzca
// Si introduce 10, contar del 1 al 10
