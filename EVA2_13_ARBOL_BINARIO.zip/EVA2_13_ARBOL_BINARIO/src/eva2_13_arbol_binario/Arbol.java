package eva2_13_arbol_binario;

/**
 *
 * @author ChaoticErnie
 */
public class Arbol {

    private Nodo root;

    public Arbol() {
        root = null;
    }

    // La primera vez que se inserta nodo se inserta debajo de la raíz
    public void agregarNodo(Nodo nuevo) {
        agregarNodoRec(root, nuevo);
    }

    private void agregarNodoRec(Nodo actual, Nodo nuevo) {
        if (root == null) { // Arbol vacío
            root = nuevo;
        } else {
            if (nuevo.getDato() > actual.getDato()) { // Mayor --> derecha
                if (actual.getRight() == null) { // Vacio, hay espacio
                    actual.setRight(nuevo);
                } else { //Hay nodo a la derecha
                    agregarNodoRec(actual.getRight(), nuevo);
                }
            } else if (nuevo.getDato() < actual.getDato()) { // Menor --> izquierda
                if (actual.getLeft() == null) { //Vacio hay espacio
                    actual.setLeft(nuevo);
                } else {
                    agregarNodoRec(actual.getLeft(), nuevo);
                }
            } else { // Valor ya existe
                System.out.println("Ya existe el valor");
            }
        }
    }

    public void imprimePostOrder() {
        postOrder(root);
    }

    private void postOrder(Nodo actual) {
        if (actual != null) {
            // leer izq
            postOrder(actual.getLeft());
            // leer der
            postOrder(actual.getRight());
            // print
            System.out.print(actual.getDato() + " - ");
        }
    }

    public void imprimePreOrder() {
        preOrder(root);
    }

    private void preOrder(Nodo actual) {
        if (actual != null) {
            // print
            System.out.print(actual.getDato() + " - ");
            // leer izq
            preOrder(actual.getLeft());
            // leer der
            preOrder(actual.getRight());
        }
    }

    public void imprimeInOrder() {
        inOrder(root);
    }

    private void inOrder(Nodo actual) {
        if (actual != null) {
            // leer izq
            preOrder(actual.getLeft());
            // print
            System.out.print(actual.getDato() + " - ");
            // leer der
            preOrder(actual.getRight());
        }
    }
}
