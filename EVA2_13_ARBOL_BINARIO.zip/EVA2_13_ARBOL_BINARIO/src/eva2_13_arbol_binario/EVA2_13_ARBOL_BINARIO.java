package eva2_13_arbol_binario;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA2_13_ARBOL_BINARIO {

    public Arbol arbol;

    public static void main(String[] args) {

        
        Arbol arbol =  new Arbol();
        arbol.agregarNodo(new Nodo(13));
        arbol.agregarNodo(new Nodo(10));
        arbol.agregarNodo(new Nodo(18));
        arbol.agregarNodo(new Nodo(2));
        arbol.agregarNodo(new Nodo(11));
        arbol.agregarNodo(new Nodo(17));
        arbol.agregarNodo(new Nodo(20));
        arbol.imprimePostOrder();
        System.out.println("------------------");
        arbol.imprimePreOrder();
        System.out.println("------------------");
        arbol.imprimeInOrder();
    }

}
