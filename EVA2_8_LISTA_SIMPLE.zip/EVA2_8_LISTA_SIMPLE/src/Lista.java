
public class Lista {

    private Nodo inicio, fin;

    public Lista() {
        // nos aeguramosque el nodo empiece en null
        inicio = null;
        fin = null;
    }

    public boolean isEmpty() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    public void añadir(Nodo nodo) {
        // primero debemos ver si la lista esta vacia
        if (isEmpty()) {
            inicio = nodo;
            fin = nodo;
        } else {
            fin.setNext(nodo);
            fin = nodo;
        }

    }

    public void imprimir() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.print(temp.getX() + "-");
            temp = temp.getNext();
        }
    }

    // cantidad de elementos que tiene la lista
    public int numNodos() {
        int conta = 0;
        Nodo temp = inicio;
        while (temp != null) {
            conta++;
            temp = temp.getNext();
        }
        return conta;
    }

    // agregar al inicio de la lista
    public void añaInicio(Nodo Nodo) {
        if (isEmpty()) {
            inicio = Nodo;
            fin = Nodo;
        } else {
            Nodo.setNext(inicio);
            inicio = Nodo;
        }
    }

    public void insertNod(int posi, Nodo nod) {
        int conta = 0; //contar los nodos
        Nodo temp = inicio;
        while (temp != null) {
            conta++;
            temp = temp.getNext();
        }
        if (conta == posi - 1) {

        }

    }

    public int size() {
        int iCont = 0;
        Nodo temp = inicio;
        while (temp != null) {
            iCont++;
        }

        return iCont++;
    }

    public void clear() {
        inicio = null;
        fin = null;
    }

    public void deleteAt(int pos) throws Exception {
        if (isEmpty()) {
            throw new Exception("La posición es inválida");
        }

        int size = size();

        if (size == 1) {
            clear();
        }

        if (size == 1) {
            clear();
        } else {
            if (pos == 0) {
                inicio = inicio.getNext();
            } else {
                int iCont = 0;
                Nodo temp = inicio;
                while (iCont < (pos - 1)) {
                    temp = temp.getNext();
                    iCont++;
                }
            }
        }
    }
}
