package eva2_15_arraylist;

import java.util.ArrayList;

/**
 * @author Ernesto Domínguez Meléndez
 */

public class EVA2_15_ARRAYLIST {

    public static void main(String[] args) {
        
        ArrayList<Integer> arrayList = new ArrayList<>();
        arrayList.add(100);
        arrayList.add(200);
        arrayList.add(300);
        arrayList.add(400);
        arrayList.add(500);
        
        

    }

}
