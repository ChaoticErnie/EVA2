
import java.util.logging.Level;
import java.util.logging.Logger;

public class Queue {

    private Nodo start;
    private Nodo end;

    public Queue() {
        this.start = null;
        this.end = null;
    }

    public boolean isEmpty() {
        if (start == null) {
            return true;
        } else {
            return false;
        }
    }

    public void add(Nodo nodo) {
        if (isEmpty()) {
            start = nodo;
            end = nodo;
        } else {
            end.setNext(nodo);
            end = nodo;
        }
    }

    public void print() {
        Nodo aux = start;
        while (aux != null) {
            System.out.print(aux.getValor() + " - ");
            aux = aux.getNext();
        }
        System.out.println("");
    }

    public int size() {
        int contador = 0;
        Nodo aux = start;
        while (aux != null) {
            contador++;
            aux = aux.getNext();
        }
        return contador;
    }

    public void addBegin(Nodo nodo) {
        if (isEmpty()) {
            start = nodo;
            end = nodo;
        } else {
            nodo.setNext(start);
            start = nodo;
        }
    }

    public void insertAt(int position, Nodo nodo) {
        int size = size();
        if (position < 0 || position >= size) {
            try {
                throw new Exception("Invalid position");
            } catch (Exception e) {
                Logger.getLogger(Queue.class.getName()).log(Level.SEVERE, null, e);
            }
        } else {
            if (position == 0) {
                addBegin(nodo);
            } else {
                int contador = 0;

                Nodo aux = start;
                while (contador < (position - 1)) {
                    aux = aux.getNext();
                    contador++;
                }
                nodo.setNext(aux.getNext());
                aux.setNext(nodo);
            }
        }
    }

    public void clear() {
        start = null;
        end = null;
    }

    public void deleteAt(int position) {
        try {
            if (isEmpty() == true) {
                try {
                    throw new Exception("List is empty");
                } catch (Exception e) {
                    Logger.getLogger(Queue.class.getName()).log(Level.SEVERE, null, e);
                }
            }
            int size = size();
            if ((position < 0) || position >= size) {
                throw new Exception("Invalid position");
            }
            if (size == 1) {//SÓLO HAY UN NODO
                clear();
            } else {
                if (position == 0) {//BORRAR EL PRIMER NODO
                    start = start.getNext();
                } else {
                    int contador = 0;

                    Nodo aux = start;
                    while (contador < (position - 1)) {
                        aux = aux.getNext();
                        contador++;
                    }
                    aux.setNext(aux.getNext().getNext());
                    if (position == (size - 1)) {
                        end = aux;
                    }
                }
            }

            if (position == 0) {
                start = start.getNext();
            }

            if (size() == 1) {
                start = null;
                end = null;
            }

        } catch (Exception e) {
            Logger.getLogger(Queue.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    public int findAt(int position) {
        int contador = 0;
        Nodo aux = start;
        while (contador < (position - 1)) {
            aux = aux.getNext();
            contador++;
        }
        return aux.getValor();
    }
}
