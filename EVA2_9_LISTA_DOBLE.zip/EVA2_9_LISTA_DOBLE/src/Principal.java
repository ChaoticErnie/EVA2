public class Principal {

    public static void main(String[] args) {

        ListaDoble list = new ListaDoble();
        
        list.add(new Nodo(10));
        list.add(new Nodo(11));
        list.add(new Nodo(13));
        list.add(new Nodo(20));
        list.add(new Nodo(30));
        
        list.print();
        
        list.printBackwards();

    }

}
