package eva2_7_lista_2;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA2_7_LISTA_2 {

    public static void main(String[] args) {

        Nodo nodo1, nodo2, nodo3;
        nodo1 = new Nodo(32);
        nodo2 = new Nodo(17);
        nodo3 = new Nodo(5);
        
        nodo1.setSiguiente(nodo2);
        nodo2.setSiguiente(nodo3);
        
        Nodo temp = nodo1;
        while(temp != null) {
            System.out.println(temp.getX() + " - ");
            temp = temp.getSiguiente();
        }
    
    }

    static class Nodo {
        private int x;
        private Nodo siguiente;
        
        public Nodo() {
            this.siguiente = null;
        }
        
        public Nodo(int x) {
            this.x = x;
            this.siguiente = siguiente;
        }
        
        public int getX() {
            return x;
        }

        public void setX(int x) {
            this.x = x;
        }
        
        public Nodo getSiguiente() {
            return siguiente;
        }
        
        public void setSiguiente(Nodo siguiente) {
            this.siguiente = siguiente;
        }
        
    }

}

/**
 * 
 */