package eva2_4_fibonacci;

/**
 * @author Ernesto Domínguez Meléndez
 */

public class EVA2_4_FIBONACCI {

    public static void main(String[] args) {
        
        System.out.println(fibonacci(6))

    }

    public static int fibonacci(int pos) {
        if (pos == 0) {
            return 0;
        } else if (pos == 1) {
            return 1;
        } else {
            return fibonacci(pos - 1) + fibonacci(pos - 2);
        }
    }
    
}
