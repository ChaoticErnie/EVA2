
public class ListaDoble {

    private Nodo start;
    private Nodo finish;

    public ListaDoble() {
        this.start = null;
        this.finish = null;
    }

    public void print() {
        Nodo aux = start;
        while (aux != null) {
            System.out.print(aux.getX() + " - ");
            aux = aux.getNext();
        }
        System.out.println("");
    }

    public int size() {
        int contador = 0;
        Nodo temp = start;
        while (temp != null) {
            contador++;
            temp = temp.getNext();
        }
        return contador;
    }

    public void clear() {
        start = null;
        finish = null;
    }

    public boolean isEmpty() {
        if (start == null) {
            return true;
        } else {
            return false;
        }
    }

    public int findAt(int pos) {
        int iCont = 0;
        Nodo temp = start;
        while (iCont < (pos - 1)) {
            temp = temp.getNext();
            iCont++;
        }
        return temp.getX();
    }

    public void add(Nodo nodo) { // Al final de lista
        if (isEmpty()) {
            start = nodo;
            finish = nodo;
        } else {
            finish.setNext(nodo); // Forwards
            nodo.setPrevious(finish); // Backwards
            finish = nodo;
        }
    }

    public void printBackwards() {
        Nodo aux = finish;
        while (aux != null) {
            System.out.print(aux.getX() + " - ");
            aux = aux.getPrevious();
        }
        System.out.println("");
    }
}
