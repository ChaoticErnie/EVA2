
public class Nodo {

    private int valor;

    private Nodo next;

    public Nodo(int x) {
        this.valor = x;
        this.next = null;
    }

    public int getValor() {
        return valor;
    }

    public Nodo getNext() {
        return next;
    }

    public void setValor(int x) {
        this.valor = x;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }

    public Nodo(int x, Nodo next) {
        this.valor = x;
        this.next = next;
    }
}
