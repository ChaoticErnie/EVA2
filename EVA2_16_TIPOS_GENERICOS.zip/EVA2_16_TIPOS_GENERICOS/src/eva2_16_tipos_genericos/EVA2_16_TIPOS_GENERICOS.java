package eva2_16_tipos_genericos;

/**
 * @author Ernesto Domínguez Meléndez
 */

public class EVA2_16_TIPOS_GENERICOS {

    public static void main(String[] args) {

        Nodo<String> nodo = new Nodo<String>();
        nodo.setValue("Hola");
        nodo.setValue("mundo");
        nodo.setValue("jaja salu2");
    }

}

class Nodo<T> {

    private T value;
    Nodo next;
    Nodo prev;

    public Nodo() {
        this.next = null;
        this.prev = null;
    }

    public Nodo(T value) {
        this.value = value;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public Nodo getNext() {
        return next;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }

    public Nodo getPrev() {
        return prev;
    }

    public void setPrev(Nodo prev) {
        this.prev = prev;
    }

}
