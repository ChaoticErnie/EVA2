/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eva2_8_lista_simple;

/**
 *
 * @author ChaoticErnie
 */
public class Lista {

    private Nodo inicio;

    public Lista() {

    }

    public Lista(Nodo inicio) {
        this.inicio = null;
    }

    // returns true if list is empty
    public boolean isEmpty() {
        if (inicio == null) {
            return true;
        } else {
            return false;
        }
    }

    // adds node at the end of list
    public void add(Nodo nuevo) {
        // Se verifica si la lista está vacía
        if (isEmpty()) {
            inicio = nuevo;
        } else {
            Nodo temp = inicio;
            while (temp.getSiguiente() != null) {
                System.out.println(temp.getSiguiente() + " - ");
                temp = temp.getSiguiente();
            }
        }
    }

    //print list
    public void print() {
        Nodo temp = inicio;
        while (temp != null) {
            System.out.println(temp.getSiguiente() + " - ");
            temp = temp.getSiguiente();
        }
    }
}
