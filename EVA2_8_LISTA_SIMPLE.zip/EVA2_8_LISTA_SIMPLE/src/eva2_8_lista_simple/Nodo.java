package eva2_8_lista_simple;

/**
 *
 * @author ChaoticErnie
 */
public class Nodo {

    private int x;
    private Nodo siguiente;

    public Nodo() {
        this.siguiente = null;
    }

    public Nodo(int x) {
        this.x = x;
        this.siguiente = siguiente;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

}
