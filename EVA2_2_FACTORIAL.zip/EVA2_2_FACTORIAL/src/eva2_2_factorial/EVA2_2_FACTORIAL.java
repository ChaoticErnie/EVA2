package eva2_2_factorial;

public class EVA2_2_FACTORIAL {

    public static void main(String[] args) {

        System.out.println("Factorial de 5: " + calculaFactorial(5));

    }

    public static int calculaFactorial(int x) {
        if (x == 0) {
            return 1;
        } else {
            return (x * calculaFactorial(x - 1));
        }
    }
}
