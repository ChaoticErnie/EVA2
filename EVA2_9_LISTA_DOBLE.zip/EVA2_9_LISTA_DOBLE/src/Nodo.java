
public class Nodo {

    private int x;

    private Nodo next;
    private Nodo previous;

    public Nodo(int x) {
        this.x = x;
        this.next = null;
        this.previous = null;
    }

    public int getX() {
        return x;
    }

    public Nodo getNext() {
        return next;
    }

    public Nodo getPrevious() {
        return previous;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }

    public Nodo(int valor, Nodo next) {
        this.x = valor;
        this.next = next;
    }

    public void setPrevious(Nodo previous) {
        this.previous = previous;
    }
}
