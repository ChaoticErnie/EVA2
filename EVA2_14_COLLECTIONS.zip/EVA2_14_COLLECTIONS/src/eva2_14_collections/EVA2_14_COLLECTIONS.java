package eva2_14_collections;

import java.util.LinkedList;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA2_14_COLLECTIONS {

    public static void main(String[] args) {

        LinkedList<String> listaEnlazada = new LinkedList<String>(); // En una lista enlazada los nodos se agregan al final
        listaEnlazada.add("Hola");
        listaEnlazada.add(" ");
        listaEnlazada.add("mundo");
        listaEnlazada.add(" ");
        listaEnlazada.add("cruel");
        listaEnlazada.add("!");
        
        listaEnlazada.addFirst("X");
        
        System.out.println(listaEnlazada);
        
        for (String string : listaEnlazada) {
            System.out.print(string + " - ");
        }
        
        System.out.println("");
        System.out.println("Cantidad de elementos: " + listaEnlazada.size());
        
        listaEnlazada.remove(2);
        
        System.out.println(listaEnlazada);

    }

}
