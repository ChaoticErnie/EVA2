
public class Principal {

    public static void main(String[] args) {
        Lista lista = new Lista();
        lista.añadir(new Nodo(5));// inicio apunta al nuevo nodo
        lista.añadir(new Nodo(3));//2
        lista.añadir(new Nodo(8));//3
        lista.añadir(new Nodo(41));//4
        lista.añadir(new Nodo(9));//5
        lista.añaInicio(new Nodo(94548));//0
        lista.insertNod(3, new Nodo(1));
        lista.imprimir();
        
        System.out.println("Cantidad = " + lista.numNodos());

        //determinamos si la lista esta vacia
        boolean empty = lista.isEmpty();

        if (empty) {
            System.out.println("vacia");
        } else {
            System.out.println("no vacia");
        }
        //agregaremos un nodo a la lista 

    }

}
