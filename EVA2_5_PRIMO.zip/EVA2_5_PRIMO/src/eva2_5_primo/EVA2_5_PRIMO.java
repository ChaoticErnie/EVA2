package eva2_5_primo;

/**
 * @author Ernesto Domínguez Meléndez
 */

public class EVA2_5_PRIMO {

    public static void main(String[] args) {
        
        

    }
    
    public static boolean esPrimoIneficiente(int x) {
        boolean result = false;
        
        return result;
    }

}
