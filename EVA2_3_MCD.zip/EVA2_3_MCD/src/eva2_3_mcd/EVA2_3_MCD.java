package eva2_3_mcd;

/**
 * @author Ernesto Domínguez Meléndez
 */
public class EVA2_3_MCD {

    public static void main(String[] args) {

        System.out.println(mcd(180, 20));
    }

    public static int mcd(int dividendo, int divisor) {
        System.out.println(dividendo + "/" + divisor);
        if (divisor == 0) {
            return dividendo;
        } else {
            int residuo = (dividendo % divisor);
            return mcd(divisor, residuo);
        }
    }

}
