package eva2_13_arbol_binario;

public class Nodo {

    private int dato;
    private Nodo right;
    private Nodo left;

    public Nodo() {

        // Reference starts as null
        right = null;
        left = null;

    }

    public Nodo(int dat) {
        dato = dat;
        right = null;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    public Nodo getRight() {
        return right;
    }

    public void setRight(Nodo right) {
        this.right = right;
    }

    public Nodo getLeft() {
        return left;
    }

    public void setLeft(Nodo left) {
        this.left = left;
    }
}
